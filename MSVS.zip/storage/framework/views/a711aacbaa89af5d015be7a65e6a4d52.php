

<?php $__env->startSection('content'); ?>

<div class="container">
        <h1><center>Información de las Unidades de Salud</h1>
    </div>
    <div class="container">
        <p></p>
        <h2>Seleccione el municipio más cercano a su domicilio para ver la información del centro de Salud</h2>
       <form action="<?php echo e(route('unidadesdesalud.index')); ?>" method="get">
       <div class="input-group"> 
       <select class="form-select" name="seleccion" aria-label="Default select example">
            <option selected>Seleccione el municipio</option>
            <option value="1">Pachuca</option>
            <option value="2">Ixmiquilpan</option>
            <option value="3">Sahagún</option>
            <option value="4">San Felipe Orizatlán</option>
            <option value="5">Tula</option>
            <option value="6">Huejutla</option>
          </select>
          <button type="submit" class="btn btn-primary">Consultar</button>
          </div>
        </form>
          <br>
          <table class="table table-hover">

            <thead class="table-light">
                <tr>
                    
                    <th>Nombre</th>
                    <th>Especialidades</th>
                    <th>Domicilio</th>
                    <th>Teléfono</th>
                    <th>Horario de atención</th>
                    <th>Email</th>
                    <th>Ubicación</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $unidadesdesalud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidaddesalud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php
                 $ubicacionUnidad= $unidaddesalud->Ubicación;
                 $mail= $unidaddesalud->email;
                 ?>
                <tr>
                    <td><?php echo e($unidaddesalud->Nombre); ?></td>
                    <td><?php echo e($unidaddesalud->Especialidades); ?></td>
                    <td><?php echo e($unidaddesalud->domicilio); ?></td>
                    <td><?php echo e($unidaddesalud->telefono); ?></td>
                    <td><?php echo e($unidaddesalud->horarioAtencion); ?></td>
                    <td><a href="mailto:<?php echo $mail?>"><?php echo e($unidaddesalud->email); ?></a></td>
                    <td><a href="<?php echo $ubicacionUnidad; ?>"><?php echo e($unidaddesalud->Ubicación); ?></a></td>
                </tr>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </tbody>
            <tbody id="table_data"></tbody>

            </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GitMSVS\resources\views/tamizaje/unidadesdesalud.blade.php ENDPATH**/ ?>