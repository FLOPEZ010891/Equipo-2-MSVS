<?php $__env->startSection('content'); ?>
<div id="login" class="login">
    <h2>Inicio de Sesión</h2>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <form id="loginForm" method="POST" action="<?php echo e(route('login.submit')); ?>">
        <?php echo csrf_field(); ?>
        <div class="input-group">
            <label for="email">Correo Electrónico:</label>
            <input type="email" id="email" name="email" required>
            <span class="error-message" id="error-email"></span>
        </div>
        <div class="input-group">
            <label for="password">Contraseña:</label>
            <input type="password" id="password" name="password" required>
            <span class="error-message" id="error-password"></span>
        </div>
        <button type="submit" class="submit-button">Iniciar Sesión</button>
    </form>
    <div class="login-links">
        <a href="<?php echo e(route('password.request')); ?>">¿Olvidaste tu contraseña?</a>
        <a href="<?php echo e(route('registro.show')); ?>">¿No tienes cuenta? Regístrate</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GitMSVS\resources\views/auth/login.blade.php ENDPATH**/ ?>