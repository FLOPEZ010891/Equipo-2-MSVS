

<?php $__env->startSection('content'); ?>
<div class="registro">
    <h2 class="text-center">Usuarios</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('usuarios.create')); ?>" class="submit-button mb-3">Crear Usuario</a>

    <form action="<?php echo e(route('usuarios.index')); ?>" method="GET" class="mb-3">
        <div class="input-group">
            <input type="text" name="buscar" class="form-control" placeholder="Buscar...">
            <button type="submit" class="btn btn-primary">Buscar</button>
        </div>
    </form>

    <table class="custom-table">
        <thead>
            <tr>
                <th>Foto de perfil</th>
                <th>Nombre</th>
                <th>Email</th>
                <th>Dirección</th>
                <th>Edad</th>
                <th>Sexo</th>
                <th>Ocupación</th>
                <th>Teléfono</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php if($usuario->imagen): ?>
                            <img src="<?php echo e(Storage::url($usuario->imagen)); ?>" alt="Imagen de perfil" class="profile-image">
                        <?php else: ?>
                            <img src="<?php echo e(asset('path/to/default-image.jpg')); ?>" alt="Imagen predeterminada" class="profile-image">
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($usuario->name); ?></td>
                    <td><?php echo e($usuario->email); ?></td>
                    <td><?php echo e($usuario->direccion); ?></td>
                    <td><?php echo e($usuario->edad); ?></td>
                    <td><?php echo e($usuario->sexo); ?></td>
                    <td><?php echo e($usuario->ocupacion); ?></td>
                    <td><?php echo e($usuario->telefono); ?></td>
                    <td class="action-buttons">
                        <a href="<?php echo e(route('usuarios.edit', $usuario->id)); ?>" class="btn btn-edit">Editar</a>
                        <form action="<?php echo e(route('usuarios.destroy', $usuario->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-delete" onclick="return confirm('¿Está seguro de eliminar este usuario?')">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($usuarios->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GitMSVS\resources\views/usuarios/index.blade.php ENDPATH**/ ?>