


<?php $__env->startSection('content'); ?>
<div class="hero">
    <div class="hero-content">
        <div class="hero-text">
            <h1>Tamizaje de Desesperanza</h1>
            <p>Un tamizaje es una evaluación preliminar que nos ayuda a identificar si existe alguna señal de alerta sobre nuestra salud mental.
                El Tamizaje de Desesperanza de Beck es una herramienta que nos ayuda a detectar sentimientos de desesperanza. ¡Anímate a contestarlo!
            </p>.</p>
            <a href="<?php echo e(route('tamizaje.desesperanza')); ?>" class="hero-button">Iniciar Tamizaje</a>
        </div>
        <div class="hero-image">
            <img src="<?php echo e(asset('img/tamizaje.png')); ?>" alt="Tamizaje de Desesperanza">
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GitMSVS\resources\views/tamizaje/index.blade.php ENDPATH**/ ?>