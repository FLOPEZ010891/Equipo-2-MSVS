

<?php $__env->startSection('content'); ?>
    <div class="registro">
        <h2 class="text-center">Editar Usuario</h2>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form id="registroForm" method="POST" action="<?php echo e(route('usuarios.update', $usuario->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="input-group">
                <label for="imagen">Imagen de perfil:</label>
                <br>
                <?php if($usuario->imagen): ?>
                    <img src="<?php echo e(asset($usuario->imagen)); ?>" class="mt-2" style="max-width: 200px;" alt="Imagen de perfil">
                <?php else: ?>
                    <p class="text-muted mt-2">No hay imagen disponible.</p>
                <?php endif; ?>
                <input type="file" id="imagen" name="imagen">
            </div>

            <div class="input-group">
                <label for="name">Nombre:</label>
                <input type="text" id="name" name="name" value="<?php echo e(old('name', $usuario->name)); ?>" required>
                <span class="error-message" id="error-name"></span>
            </div>

            <div class="input-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo e(old('email', $usuario->email)); ?>" readonly>
                <span class="error-message" id="error-email"></span>
            </div>

            <div class="input-group">
                <label for="direccion">Dirección:</label>
                <input type="text" id="direccion" name="direccion" value="<?php echo e(old('direccion', $usuario->direccion)); ?>" required>
                <span class="error-message" id="error-direccion"></span>
            </div>

            <div class="input-group">
                <label for="edad">Edad:</label>
                <input type="number" id="edad" name="edad" value="<?php echo e(old('edad', $usuario->edad)); ?>" required>
                <span class="error-message" id="error-edad"></span>
            </div>

            <div class="input-group">
                <label for="sexo">Sexo:</label>
                <select id="sexo" name="sexo" required>
                    <option value="Hombre" <?php echo e(old('sexo', $usuario->sexo) === 'Hombre' ? 'selected' : ''); ?>>Hombre</option>
                    <option value="Mujer" <?php echo e(old('sexo', $usuario->sexo) === 'Mujer' ? 'selected' : ''); ?>>Mujer</option>
                    <option value="No binario" <?php echo e(old('sexo', $usuario->sexo) === 'No binario' ? 'selected' : ''); ?>>No binario</option>
                </select>
                <span class="error-message" id="error-sexo"></span>
            </div>

            <div class="input-group">
                <label for="ocupacion">Ocupación:</label>
                <input type="text" id="ocupacion" name="ocupacion" value="<?php echo e(old('ocupacion', $usuario->ocupacion)); ?>">
                <span class="error-message" id="error-ocupacion"></span>
            </div>

            <div class="input-group">
                <label for="telefono">Teléfono:</label>
                <input type="text" id="telefono" name="telefono" value="<?php echo e(old('telefono', $usuario->telefono)); ?>" required>
                <span class="error-message" id="error-telefono"></span>
            </div>

            <button type="submit" class="submit-button">Actualizar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GitMSVS\resources\views/usuarios/edit.blade.php ENDPATH**/ ?>