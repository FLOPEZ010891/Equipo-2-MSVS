

<?php $__env->startSection('content'); ?>
    <div class="container foro-create-container">
        <div class="foro-create-text">
            <h1>Participar en el Foro</h1>
            <p>Deja tu mensaje y participa en el foro. Comparte tus experiencias y consejos con otros adolescentes.</p>
            <form action="<?php echo e(route('forum.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <textarea name="content" class="form-control" rows="5" placeholder="Escribe tu mensaje aquí..."></textarea>
                    <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit" class="btn btn-primary foro-submit-button">Enviar</button>
            </form>
        </div>
        
        <div class="foro-messages">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="foro-message">
                    <p><?php echo e($post->content); ?></p>
                    <small><?php echo e($post->published_at->format('d M Y, H:i')); ?> - <?php echo e($post->user_name); ?></small>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GitMSVS\resources\views/forum/create.blade.php ENDPATH**/ ?>