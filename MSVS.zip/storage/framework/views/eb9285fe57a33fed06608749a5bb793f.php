


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="alert alert-success" role="alert">
            <h3>Tus resultados se han guardado satisfactoriamente</h3>
            <p><?php echo e($mensaje); ?></p>
            <a class="btn btn-primary" href="<?php echo e(route('unidadesdesalud.index')); ?>">Consultar Centros de Salud</a>
            <a class="btn btn-primary" href="<?php echo e(url('/autocuidado')); ?>" role="button">Continuar</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GitMSVS\resources\views/tamizaje/resultado.blade.php ENDPATH**/ ?>