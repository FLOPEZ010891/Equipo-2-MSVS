

<?php $__env->startSection('content'); ?>
    <div class="registro">
        <h2 class="text-center">Crear Usuario</h2>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form id="registroForm" method="POST" action="<?php echo e(route('usuarios.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="input-group">
                <label for="name">Nombre:</label>
                <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" required>
                <span class="error-message" id="error-name"></span>
            </div>
            <div class="input-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required>
                <span class="error-message" id="error-email"></span>
            </div>
            <div class="input-group">
                <label for="direccion">Dirección:</label>
                <input type="text" id="direccion" name="direccion" value="<?php echo e(old('direccion')); ?>" required>
                <span class="error-message" id="error-direccion"></span>
            </div>
            <div class="input-group">
                <label for="edad">Edad:</label>
                <input type="number" id="edad" name="edad" value="<?php echo e(old('edad')); ?>" required>
                <span class="error-message" id="error-edad"></span>
            </div>
            <div class="input-group">
                <label for="sexo">Sexo:</label>
                <select id="sexo" name="sexo" required>
                    <option value="Hombre" <?php echo e(old('sexo') == 'Hombre' ? 'selected' : ''); ?>>Hombre</option>
                    <option value="Mujer" <?php echo e(old('sexo') == 'Mujer' ? 'selected' : ''); ?>>Mujer</option>
                    <option value="Otro" <?php echo e(old('sexo') == 'Otro' ? 'selected' : ''); ?>>Otro</option>
                </select>
                <span class="error-message" id="error-sexo"></span>
            </div>
            <div class="input-group">
                <label for="ocupacion">Ocupación:</label>
                <input type="text" id="ocupacion" name="ocupacion" value="<?php echo e(old('ocupacion')); ?>">
                <span class="error-message" id="error-ocupacion"></span>
            </div>
            <div class="input-group">
                <label for="telefono">Teléfono:</label>
                <input type="text" id="telefono" name="telefono" value="<?php echo e(old('telefono')); ?>" required>
                <span class="error-message" id="error-telefono"></span>
            </div>
            <div class="input-group">
                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required>
                <span class="error-message" id="error-password"></span>
            </div>
            <div class="input-group">
                <label for="password_confirmation">Confirmar Contraseña:</label>
                <input type="password" id="password_confirmation" name="password_confirmation" required>
                <span class="error-message" id="error-password_confirmation"></span>
            </div>
            <div class="input-group">
                <label for="imagen">Imagen:</label>
                <input type="file" id="imagen" name="imagen" required>
                <span class="error-message" id="error-imagen"></span>
            </div>
            <button type="submit" class="submit-button">Guardar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GitMSVS\resources\views/usuarios/create.blade.php ENDPATH**/ ?>