<nav class="navbar">
    <div class="logo">
        <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo">
        <a href="<?php echo e(route('index')); ?>"><span>MSVS</span></a>
    </div>
    <ul class="menu">
        <?php if(auth()->guard()->guest()): ?>
            <li><a href="<?php echo e(route('login')); ?>">Inicio de sesión</a></li>
            <li><a href="<?php echo e(route('register')); ?>">Registro</a></li>
        <?php endif; ?>
        <?php if(auth()->guard()->check()): ?>
            <li><a href="<?php echo e(route('autocuidado')); ?>">Autocuidado</a></li>
            <li><a href="<?php echo e(route('tamizaje.index')); ?>">Tamizajes</a></li>
            <li><a href="<?php echo e(route('forum.index')); ?>">Foros de ayuda</a></li>
            <li><a href="<?php echo e(route('usuarios.index')); ?>">Usuarios</a></li>
            <li>
                <a href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault();
                             document.getElementById('logout-form').submit();">
                    Cerrar sesión
                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </li>
        <?php endif; ?>
    </ul>
</nav>
<?php /**PATH C:\xampp\htdocs\GitMSVS\resources\views/layouts/nav.blade.php ENDPATH**/ ?>